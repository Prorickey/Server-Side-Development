### RESOURCES
- https://www.sqlite.org/foreignkeys.html
- 